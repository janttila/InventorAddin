Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with the assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("$projectname$")>
<Assembly: AssemblyDescription("Inventor 2027 add-in")>
<Assembly: AssemblyCompany("Jodant")>
<Assembly: AssemblyProduct("$projectname$")>
<Assembly: AssemblyCopyright("Copyright ©$year$ Jodant.")>
<Assembly: AssemblyTrademark("")>
<Assembly: ComVisible(True)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("$guid2$")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")>
